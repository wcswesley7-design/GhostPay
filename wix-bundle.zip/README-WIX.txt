GhostPay Wix Bundle

- Use as paginas HTML deste bundle no Wix (ou como referencia para criar as paginas).
- Troque https://app.seudominio.com pelo dominio real do console.
- Arquivos:
  index.html, platform.html, security.html, developers.html, pricing.html, support.html, 404.html
  styles.css, site.js, assets/ghostpay-logo.png